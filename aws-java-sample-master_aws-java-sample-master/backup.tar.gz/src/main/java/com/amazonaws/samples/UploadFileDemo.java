package com.amazonaws.samples;

import java.io.*;
import java.util.Properties;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import oracle.cloudstorage.ftm.CloudStorageClass;
import oracle.cloudstorage.ftm.FileTransferAuth;
import oracle.cloudstorage.ftm.FileTransferManager;
import oracle.cloudstorage.ftm.TransferResult;
import oracle.cloudstorage.ftm.UploadConfig;
import oracle.cloudstorage.ftm.exception.ClientException;
import oracle.cloudstorage.ftm.DownloadConfig;


public class UploadFileDemo {
    private static final String className = UploadFileDemo.class.getSimpleName();
    private static final String demoAccountPropertiesFilepath = "";
    private static final String restoreDirPath = "C:\\Users\\yasaygil\\Downloads";

    public static <FileMd5Calculator> void main(String[] args) throws Exception {
        Properties prop = new Properties();
        try (InputStream is = new FileInputStream(demoAccountPropertiesFilepath)) {
            prop.load(is);
        } catch (Exception e) {
            System.out.println("Failed to read demo account properties file.");
            throw e;
        }
        FileTransferAuth auth = new FileTransferAuth(prop.getProperty("mehmetucar@me.com"), prop.getProperty("Brn223363*"),
                prop.getProperty("Storage"), prop.getProperty("https://boranyazilim.storage.oraclecloud.com/auth/v1.0"), prop.getProperty("boranyazilim"));

        FileTransferManager manager = null;
        try {
            manager = FileTransferManager.getDefaultFileTransferManager(auth);

            String containerName = "test";
            File file = new File("sample_5MB.pdf");
            UploadConfig uploadConfig = new UploadConfig();
            uploadConfig.setOverwrite(true);
            uploadConfig.setStorageClass(CloudStorageClass.Standard);
            uploadConfig.setSegmentsContainer("myContainer-Segments");
            uploadConfig.setSegmentSize(1048576);
            System.out.println("Uploading file " + file.getName() + " to container " + containerName);
            TransferResult uploadResult = manager.upload(uploadConfig, containerName, null, file);
            System.out.println("Upload completed. Result:" + uploadResult.toString());
                        
            //Download begins here
            // Create the restoreDirPath if required
            File restoreDir = new File(restoreDirPath);
            if (!restoreDir.isDirectory()) {
                    restoreDir.mkdir();
            }
            String objectName = "sample_5MB.pdf";
            File downloadfile = new File(restoreDirPath + File.separator + "concatenated-" + objectName);
            DownloadConfig downloadConfig = new DownloadConfig();
            System.out.println("Downloading file " + downloadfile.getName() + " from container " + containerName);
            TransferResult downloadResult = manager.download(downloadConfig, containerName, objectName, downloadfile);
            System.out.println("Download completed. State:" + downloadResult.getState());
                    
            //check MD5 checksum here

        } catch (ClientException ce) {
            System.out.println("Operation failed. " + ce.getMessage());
        } finally {
            if (manager != null) {
                                manager.shutdown();
            }
        }
    }
}